<html>
<body>

<form action="delete.php" method="get">
<H2> Borrar clientes</H2>
NIF: <input type="text" name="nif"><br>

<input type="submit">
</form>

</body>
</html>